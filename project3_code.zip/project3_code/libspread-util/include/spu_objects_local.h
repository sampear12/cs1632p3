/*
 * The Spread Toolkit.
 *     
 * The contents of this file are subject to the Spread Open-Source
 * License, Version 1.0 (the ``License''); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://www.spread.org/license/
 *
 * or in the file ``license.txt'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Spread are:
 *  Yair Amir, Michal Miskin-Amir, Jonathan Stanton, John Schultz.
 *
 *  Copyright (C) 1993-2024 Spread Concepts LLC <info@spreadconcepts.com>
 *
 *  All Rights Reserved.
 *
 * Major Contributor(s):
 * ---------------
 *    Amy Babay            babay@pitt.edu - accelerated ring protocol.
 *    Ryan Caudy           rcaudy@gmail.com - contributions to process groups.
 *    Claudiu Danilov      claudiu@acm.org - scalable wide area support.
 *    Cristina Nita-Rotaru crisn@cs.purdue.edu - group communication security.
 *    Theo Schlossnagle    jesus@omniti.com - Perl, autoconf, old skiplist.
 *    Dan Schoenblum       dansch@cnds.jhu.edu - Java interface.
 *
 */


/* objects.h 
 *  main declarations of objects
 * Copyright 1997-2012 Jonathan Stanton <jonathan@spread.org> 
 *
 */

#ifndef OBJECTS_LOCAL_H
#define OBJECTS_LOCAL_H

/* Object types 
 *
 * Object types must start with FIRST_APPLICATION_OBJECT_TYPE and go up.
 */

/* Sample declartion of object number
 * first_val = (FIRST_APPLICATION_OBJECT_TYPE + 1)
#define MY_FIRST_OBJ  = first_val
*/


/* Highest valid object number is defined in objects.h as UNKNOWN_OBJ */

#endif /* OBJECTS_LOCAL_H */
